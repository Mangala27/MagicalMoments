
# MagicalMoments

**AI-powered emotional companions that create comfort, play, and learning — one child, one voice, one magical moment at a time.**

## 🔮 What It Is
MagicalMoments is a voice-based AI companion platform designed for children aged 3–5 in hospitals and at home. Built with GPT-4, ElevenLabs, and lipsync video tech, it brings to life four lovable characters:

- **Tilly** – a storytelling bestie
- **Nads** – a silly, adventurous buddy
- **Granny Noni** – a nurturing grandmother figure
- **Twinklehop** – a bouncy cartoon bunny

Children hear their names spoken, choose what they want to do (learn, laugh, listen, sing), and each avatar responds like a real friend — in real time.

## 🗣️ What It Does
- Real-time voice conversations using GPT-4 + ElevenLabs
- Lip-synced avatar greetings with video playback
- Mobile reminders for meals, medicine, and moments of care
- Gentle animations: balloons, flowers, surprise jokes
- Personalized: Each child chooses their own Bestie + favorite topics
- Content includes: stories, sing-alongs, jokes, puzzles, and emotional affirmations

## 🧠 Tech Stack
- GPT-4 (Chat + Personalization)
- ElevenLabs (Real-time voice generation)
- D-ID / Wav2Lip (MP4 lipsync animations)
- JSON/SQL-based character and content architecture
- Mobile alert capability via Twilio/SMS

## 🧾 Assets Included
- 4 Characters × 4–5 image avatars each
- Voice ID + intro/outro for each (Bella, Rachel, Lilly, Jonny Boy)
- Sample file paths for MP4s, audio, and structured content (stories, jokes, puzzles, motivation)
- JSON + SQL-ready schema for profiles, reminders, assets

## 📦 Folder Structure
Includes:
- `MagicalMoments_CharactersFull.json`
- This `README.md`
